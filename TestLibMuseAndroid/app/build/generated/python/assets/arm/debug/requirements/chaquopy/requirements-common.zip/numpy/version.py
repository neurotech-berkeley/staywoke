
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.14.2'
version = '1.14.2'
full_version = '1.14.2'
git_revision = '6a58e25703cbecb6786faa09a04ae2ec8221348b'
release = True

if not release:
    version = full_version
